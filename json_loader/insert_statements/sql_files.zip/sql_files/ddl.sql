CREATE TABLE IF NOT EXISTS lineups 
(lineup_id                 INTEGER NOT NULL PRIMARY KEY, 
goalkeeper                 INTEGER NOT NULL,  
right_back                 INTEGER NOT NULL,  
right_center_back          INTEGER NOT NULL, 
left_center_back           INTEGER NOT NULL, 
left_back                  INTEGER NOT NULL, 
right_defensive_midfield   INTEGER NOT NULL, 
left_defensive_midfield    INTEGER NOT NULL, 
right_midfield             INTEGER NOT NULL, 
left_midfield              INTEGER NOT NULL, 
right_center_forward       INTEGER NOT NULL, 
left_center_forward        INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS teams 
(team_id     INTEGER NOT NULL PRIMARY KEY, 
team_name    VARCHAR(255) NOT NULL, 
team_gender  VARCHAR(255) NOT NULL, 
team_group   VARCHAR(255),  
team_country VARCHAR(255) NOT NULL);
CREATE TABLE IF NOT EXISTS competitions 
(competition_id     INTEGER NOT NULL, 
season_id           INTEGER NOT NULL,  
competition_name    VARCHAR(255) NOT NULL, 
season_name         VARCHAR(255) NOT NULL, 
competition_gender  VARCHAR(255) NOT NULL, 
country             VARCHAR(255) NOT NULL, 
PRIMARY KEY (competition_id, season_id));
CREATE TABLE IF NOT EXISTS stadiums 
(stadium_id     INTEGER NOT NULL PRIMARY KEY, 
stadium_name    VARCHAR(255) NOT NULL, 
country         VARCHAR(255) NOT NULL);
CREATE TABLE IF NOT EXISTS managers 
(manager_id           INTEGER NOT NULL, 
manager_name          VARCHAR(255) NOT NULL, 
manager_nickname      VARCHAR(255), 
dob                   DATE NOT NULL, 
country               VARCHAR(255) NOT NULL, 
team_id               INTEGER NOT NULL, 
PRIMARY KEY (manager_id, team_id),  
FOREIGN KEY (team_id) REFERENCES teams(team_id));
CREATE TABLE IF NOT EXISTS referees 
(referee_id     INTEGER NOT NULL PRIMARY KEY, 
referee_name    VARCHAR(255) NOT NULL, 
country         VARCHAR(255) NOT NULL);
CREATE TABLE IF NOT EXISTS matches 
(match_id            INTEGER NOT NULL PRIMARY KEY, 
match_date           DATE NOT NULL,  
kick_off             TIME NOT NULL, 
competition_id       INTEGER NOT NULL, 
season_id            INTEGER NOT NULL, 
home_team_id         INTEGER NOT NULL, 
away_team_id         INTEGER NOT NULL, 
home_score           INTEGER NOT NULL, 
away_score           INTEGER NOT NULL, 
match_status         VARCHAR(255) NOT NULL, 
match_week           INTEGER NOT NULL, 
competition_stage    VARCHAR(255) NOT NULL, 
stadium_id           INTEGER, 
referee_id           INTEGER, 
FOREIGN KEY (competition_id, season_id) REFERENCES competitions(competition_id, season_id), 
FOREIGN KEY (stadium_id) REFERENCES stadiums(stadium_id), 
FOREIGN KEY (referee_id) REFERENCES referees(referee_id));
CREATE TABLE IF NOT EXISTS players 
(player_id      INTEGER NOT NULL PRIMARY KEY, 
player_name     VARCHAR(255) NOT NULL,  
player_nickname VARCHAR(255), 
jersey_number   INTEGER NOT NULL, 
country         VARCHAR(255) NOT NULL);
CREATE TABLE IF NOT EXISTS events 
(event_id            VARCHAR(255) NOT NULL PRIMARY KEY, 
match_id             INTEGER NOT NULL,  
index                INTEGER NOT NULL, 
period               INTEGER NOT NULL, 
timestamp            TIME NOT NULL, 
minute               INTEGER NOT NULL, 
second               INTEGER NOT NULL, 
type                 VARCHAR(255) NOT NULL, 
possession            INTEGER NOT NULL, 
possession_team_id    INTEGER NOT NULL, 
play_pattern         VARCHAR(255) NOT NULL, 
team_id              INTEGER, 
duration             FLOAT, 
location_x             FLOAT, 
location_y             FLOAT, 
under_pressure       BOOLEAN, 
off_camera           BOOLEAN, 
out                  BOOLEAN, 
player_id            INTEGER, 
FOREIGN KEY (match_id) REFERENCES matches(match_id), 
FOREIGN KEY (team_id) REFERENCES teams(team_id), 
FOREIGN KEY (player_id) REFERENCES players(player_id), 
FOREIGN KEY (possession_team_id) REFERENCES teams(team_id));
CREATE TABLE IF NOT EXISTS clearance 
(event_id      VARCHAR(255) NOT NULL PRIMARY KEY, 
aerial_won     BOOLEAN, 
body_part      VARCHAR(255),  
FOREIGN KEY (event_id) REFERENCES events(event_id));
CREATE TABLE IF NOT EXISTS dribble_past 
(event_id      VARCHAR(255) NOT NULL PRIMARY KEY, 
counterpress   BOOLEAN, 
FOREIGN KEY (event_id) REFERENCES events(event_id));
CREATE TABLE IF NOT EXISTS duel 
(event_id   VARCHAR(255) NOT NULL PRIMARY KEY, 
type        VARCHAR(255), 
outcome     VARCHAR(255), 
FOREIGN KEY (event_id) REFERENCES events(event_id));
CREATE TABLE IF NOT EXISTS foul_committed 
(event_id       VARCHAR(255) NOT NULL PRIMARY KEY, 
counterpress    VARCHAR(255), 
offensive       BOOLEAN, 
type            VARCHAR(255), 
advantage       BOOLEAN, 
penalty         VARCHAR(255), 
card            VARCHAR(255), 
FOREIGN KEY (event_id) REFERENCES events(event_id));
CREATE TABLE IF NOT EXISTS goal_keeper 
(event_id       VARCHAR(255) NOT NULL PRIMARY KEY, 
position        VARCHAR(255), 
end_location_x  FLOAT, 
end_location_y  FLOAT, 
technique       VARCHAR(255), 
body_part       VARCHAR(255), 
type            VARCHAR(255), 
outcome         VARCHAR(255), 
FOREIGN KEY (event_id) REFERENCES events(event_id));
CREATE TABLE IF NOT EXISTS half_start 
(event_id          VARCHAR(255) NOT NULL PRIMARY KEY, 
late_video_start   BOOLEAN, 
FOREIGN KEY (event_id) REFERENCES events(event_id));
CREATE TABLE IF NOT EXISTS miscontrol 
(event_id      VARCHAR(255) NOT NULL PRIMARY KEY, 
aerial_won     BOOLEAN, 
FOREIGN KEY (event_id) REFERENCES events(event_id));
CREATE TABLE IF NOT EXISTS pressure 
(event_id      VARCHAR(255) NOT NULL PRIMARY KEY, 
counterpress   BOOLEAN, 
FOREIGN KEY (event_id) REFERENCES events(event_id));
CREATE TABLE IF NOT EXISTS shot 
(event_id         VARCHAR(255) NOT NULL PRIMARY KEY, 
key_pass_id       VARCHAR(255),  
end_location_x    FLOAT,  
end_location_y    FLOAT,  
end_location_z    FLOAT,  
aerial_won        BOOLEAN,  
follows_dribble   BOOLEAN,  
first_time        BOOLEAN,  
open_goal         BOOLEAN,  
statsbomb_xg      FLOAT,  
deflected         BOOLEAN,  
technique         VARCHAR(255),  
body_part         VARCHAR(255),  
type              VARCHAR(255),  
outcome           VARCHAR(255),  
FOREIGN KEY (event_id) REFERENCES events(event_id));
CREATE TABLE IF NOT EXISTS fifty_fifty 
(event_id          VARCHAR(255) NOT NULL PRIMARY KEY, 
outcome            VARCHAR(255),  
counterpress       BOOLEAN,  
FOREIGN KEY (event_id) REFERENCES events(event_id));
CREATE TABLE IF NOT EXISTS bad_behaviour 
(event_id        VARCHAR(255) NOT NULL PRIMARY KEY, 
card             VARCHAR(255) NOT NULL,  
FOREIGN KEY (event_id) REFERENCES events(event_id));
CREATE TABLE IF NOT EXISTS tactical_shift 
(event_id    VARCHAR(255) NOT NULL PRIMARY KEY, 
formation    INTEGER,  
lineup_id    INTEGER,  
FOREIGN KEY (event_id) REFERENCES events(event_id),  
FOREIGN KEY (lineup_id) REFERENCES lineups(lineup_id));
CREATE TABLE IF NOT EXISTS ball_receipt 
(event_id    VARCHAR(255) NOT NULL PRIMARY KEY, 
outcome      VARCHAR(255),  
FOREIGN KEY (event_id) REFERENCES events(event_id));
CREATE TABLE IF NOT EXISTS ball_recovery 
(event_id            VARCHAR(255) NOT NULL PRIMARY KEY, 
offensive            BOOLEAN,  
recovery_failure     BOOLEAN,  
FOREIGN KEY (event_id) REFERENCES events(event_id));
CREATE TABLE IF NOT EXISTS injury_stoppage 
(event_id    VARCHAR(255) NOT NULL PRIMARY KEY, 
in_chain     BOOLEAN,  
FOREIGN KEY (event_id) REFERENCES events(event_id));
CREATE TABLE IF NOT EXISTS substitution 
(event_id      VARCHAR(255) NOT NULL PRIMARY KEY, 
replacement    VARCHAR(255),  
outcome        VARCHAR(255),  
FOREIGN KEY (event_id) REFERENCES events(event_id));
CREATE TABLE IF NOT EXISTS starting_xi 
(event_id    VARCHAR(255) NOT NULL PRIMARY KEY, 
formation    INTEGER,  
lineup_id    INTEGER,  
FOREIGN KEY (event_id) REFERENCES events(event_id),  
FOREIGN KEY (lineup_id) REFERENCES lineups(lineup_id));
CREATE TABLE IF NOT EXISTS block 
(event_id       VARCHAR(255) NOT NULL PRIMARY KEY, 
deflection      BOOLEAN,  
offensive       BOOLEAN,  
save_block      BOOLEAN,  
counterpress    BOOLEAN,  
FOREIGN KEY (event_id) REFERENCES events(event_id));
CREATE TABLE IF NOT EXISTS interception 
(event_id          VARCHAR(255) NOT NULL PRIMARY KEY, 
outcome            VARCHAR(255) NOT NULL,  
FOREIGN KEY (event_id) REFERENCES events(event_id));
CREATE TABLE IF NOT EXISTS carry 
(event_id        VARCHAR(255) NOT NULL PRIMARY KEY, 
end_location_x             INTEGER NOT NULL, 
end_location_y             INTEGER NOT NULL,  
FOREIGN KEY (event_id) REFERENCES events(event_id));
CREATE TABLE IF NOT EXISTS foul_won 
(event_id       VARCHAR(255) NOT NULL PRIMARY KEY, 
defensive      BOOLEAN,  
advantage       BOOLEAN,  
penalty      BOOLEAN,  
FOREIGN KEY (event_id) REFERENCES events(event_id));
CREATE TABLE IF NOT EXISTS dribble 
(event_id    VARCHAR(255) NOT NULL PRIMARY KEY, 
overrun      BOOLEAN,  
nutmeg       BOOLEAN,  
outcome      VARCHAR(255),  
no_touch     BOOLEAN,  
FOREIGN KEY (event_id) REFERENCES events(event_id));

CREATE TABLE IF NOT EXISTS pass 
(event_id           VARCHAR(255) NOT NULL PRIMARY KEY, 
recepient_id        INTEGER,  
length              FLOAT,  
angle               FLOAT, 
height              VARCHAR(255), 
end_location_x      FLOAT, 
end_location_y      FLOAT, 
assisted_shot_id    VARCHAR(255), 
deflected           BOOLEAN, 
miscommunication    BOOLEAN, 
cross_              BOOLEAN, 
switch              BOOLEAN, 
shot_assist         BOOLEAN, 
goal_assist         BOOLEAN, 
body_part           VARCHAR(255), 
type                VARCHAR(255), 
outcome             VARCHAR(255), 
technique           VARCHAR(255),  
through_ball        BOOLEAN, 
FOREIGN KEY (event_id) REFERENCES events(event_id));
