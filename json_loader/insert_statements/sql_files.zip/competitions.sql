INSERT INTO competitions (competition_id, season_id, competition_name, season_name, competition_gender, country) VALUES (11, 90, 'La Liga', '2020/2021', 'male', 'Spain');
INSERT INTO competitions (competition_id, season_id, competition_name, season_name, competition_gender, country) VALUES (11, 42, 'La Liga', '2019/2020', 'male', 'Spain');
INSERT INTO competitions (competition_id, season_id, competition_name, season_name, competition_gender, country) VALUES (2, 44, 'Premier League', '2003/2004', 'male', 'England');
INSERT INTO competitions (competition_id, season_id, competition_name, season_name, competition_gender, country) VALUES (11, 4, 'La Liga', '2018/2019', 'male', 'Spain');
